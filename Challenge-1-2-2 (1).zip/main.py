# LEAP YEAR 
___
year % 4 == 0 &
year % 100!= 0 /
year % 400 == 0
___


def isLeapyear(year):
  if(year % 4 == 0 and year % 100! =0) or year % 40040￼
  